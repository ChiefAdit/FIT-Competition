package com.relevanx.tcom.activity.order

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.relevanx.tcom.api.ApiConfig
import com.relevanx.tcom.api.OrderRequest
import com.relevanx.tcom.api.OrderResponse

class OrderViewModel : ViewModel() {
    private val _order = MutableLiveData<OrderResponse>()
    val order: MutableLiveData<OrderResponse> = _order

    fun getOrderResponse(uid: String){
        val client = ApiConfig.getApiService()
        client.getOrder(OrderRequest(uid)).enqueue(object : retrofit2.Callback<OrderResponse> {
            override fun onResponse(
                call: retrofit2.Call<OrderResponse>,
                response: retrofit2.Response<OrderResponse>
            ) {
                if (response.isSuccessful) {
                    _order.value = response.body()
                }
            }

            override fun onFailure(call: retrofit2.Call<OrderResponse>, t: Throwable) {
                t.printStackTrace()
            }
        })
    }
}