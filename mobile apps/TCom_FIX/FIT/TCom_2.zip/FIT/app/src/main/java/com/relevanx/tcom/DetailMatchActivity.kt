package com.relevanx.tcom

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DetailMatchActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_match)
    }
}