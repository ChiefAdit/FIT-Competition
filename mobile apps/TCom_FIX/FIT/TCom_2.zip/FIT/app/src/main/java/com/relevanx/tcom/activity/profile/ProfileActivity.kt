package com.relevanx.tcom.activity.profile

import android.content.Intent
import android.media.tv.AdRequest
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import com.bumptech.glide.Glide
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import com.relevanx.tcom.BottomHelper
import com.relevanx.tcom.EditProfileActivity
import com.relevanx.tcom.R
import com.relevanx.tcom.databinding.ActivityProfileBinding
import com.relevanx.tcom.activity.login.MainActivity

class ProfileActivity : AppCompatActivity() {
    private lateinit var binding: ActivityProfileBinding
    lateinit var mGoogleSignInClient: GoogleSignInClient
//        lateinit var adView: AdView
//        lateinit var adRequest: AdRequest

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken("46821013546-5eq2lb1tr4p3renfmhgmmibt1fs5d182.apps.googleusercontent.com")
            .requestEmail()
            .build()
        mGoogleSignInClient= GoogleSignIn.getClient(this,gso)

        val auth = Firebase.auth.currentUser

        val profileImg = auth?.photoUrl.toString()
        Glide.with(this).load(profileImg).into(binding.profileImage)
        binding.emailProfile.text = auth?.email
        binding.nameProfile.text = auth?.displayName
        binding.phoneProfile.text = auth?.phoneNumber


        bottom()
    }

    private fun bottom() {
        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottomNavigationView)
        bottomNavigationView.selectedItemId = R.id.profile
        BottomHelper.setupBottomNavigation(this)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.profile_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle menu item clicks here
        when (item.itemId) {
            R.id.settings -> {
                // Handle Notifikasi click
//                val intent= Intent(this, SettingsActivity::class.java)
//                startActivity(intent)
//                finish()
//                return true
            }
            R.id.edit_profil -> {
                // Handle Edit Profil click
                val intent= Intent(this, EditProfileActivity::class.java)
                startActivity(intent)
                finish()
                return true
            }
            R.id.logout -> {
                // Handle Logout click
                mGoogleSignInClient.signOut().addOnCompleteListener {
                    val intent= Intent(this, MainActivity::class.java)
                    startActivity(intent)
                    finish()
                }
                Toast.makeText(this, "Logout", Toast.LENGTH_SHORT).show()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}