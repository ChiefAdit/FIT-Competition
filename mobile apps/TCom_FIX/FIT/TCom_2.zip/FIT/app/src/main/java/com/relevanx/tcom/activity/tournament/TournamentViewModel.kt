package com.relevanx.tcom.activity.tournament

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.relevanx.tcom.api.ApiConfig
import com.relevanx.tcom.api.TournamentRequest
import com.relevanx.tcom.api.TournamentResponse

class TournamentViewModel : ViewModel() {
    private val _tournament = MutableLiveData<TournamentResponse>()
    val tournament: MutableLiveData<TournamentResponse> = _tournament

    fun getTournament(){
        val client = ApiConfig.getApiService()
        client.getTournament(TournamentRequest("","","")).enqueue(object : retrofit2.Callback<TournamentResponse> {
            override fun onResponse(
                call: retrofit2.Call<TournamentResponse>,
                response: retrofit2.Response<TournamentResponse>
            ) {
                if (response.isSuccessful) {
                    _tournament.value = response.body()
                }
            }

            override fun onFailure(call: retrofit2.Call<TournamentResponse>, t: Throwable) {
                t.printStackTrace()
            }
        })
    }
}