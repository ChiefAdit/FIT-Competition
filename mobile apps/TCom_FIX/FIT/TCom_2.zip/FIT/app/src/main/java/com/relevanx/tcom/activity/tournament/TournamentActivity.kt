package com.relevanx.tcom.activity.tournament

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.widget.PopupMenu
import androidx.cardview.widget.CardView
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.relevanx.tcom.BottomHelper
import com.relevanx.tcom.R
import com.relevanx.tcom.activity.home.HomeActivity
import com.relevanx.tcom.adapter.TournamentAdapter
import com.relevanx.tcom.api.TournamentResponse
import com.relevanx.tcom.databinding.ActivityTournamentBinding

class TournamentActivity : AppCompatActivity() {
    private lateinit var binding: ActivityTournamentBinding
    private lateinit var viewModel: TournamentViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTournamentBinding.inflate(layoutInflater)
        setContentView(binding.root)
        viewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory())[TournamentViewModel::class.java]

        viewModel.tournament.observe(this){ setTournamnet(it) }

        viewModel.getTournament()

//        setTournamnet(TournamentDummyData.getDummyTournamentList())

        val filterImageView = findViewById<CardView>(R.id.filterCardView)
        filterImageView.setOnClickListener { view ->
            showFilterPopupMenu(view)
        }

        bottom()
    }

    override fun onBackPressed() {
        startActivity(Intent(this, HomeActivity::class.java))
        finish()
    }

    private fun setTournamnet(dummyTournamentList: TournamentResponse) {
        binding.recomendationRv.layoutManager = LinearLayoutManager(this)
        binding.recomendationRv.adapter = TournamentAdapter(dummyTournamentList)
    }

    private fun showFilterPopupMenu(view: View) {
        val popupMenu = PopupMenu(this, view)
        popupMenu.inflate(R.menu.filter_menu)

        popupMenu.setOnMenuItemClickListener { item: MenuItem ->
            when (item.itemId) {
                R.id.sort_location -> {
                    // Kode untuk filter_option1
                    Toast.makeText(this, "Filter by location", Toast.LENGTH_SHORT).show()
                    true
                }
                R.id.sort_time -> {
                    // Kode untuk filter_option2
                    Toast.makeText(this, "Filter by time", Toast.LENGTH_SHORT).show()
                    true
                }
                // Tambahkan lebih banyak opsi filter jika diperlukan
                else -> false
            }
        }

        // Tampilkan PopupMenu
        popupMenu.show()
    }

    private fun bottom() {
        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottomNavigationView)
        bottomNavigationView.selectedItemId = R.id.home
        BottomHelper.setupBottomNavigation(this)
    }
}