package com.relevanx.tcom

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DetailRegisterTournament : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_register_tournament)
    }
}